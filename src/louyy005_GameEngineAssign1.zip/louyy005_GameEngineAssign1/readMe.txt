Dear assessor，
The description of implement for each method is in the self assessment, hope everything is clear enough for you to understand. 
Thanks for your time to assess my assignment.  :)

Best regard,
Jessica